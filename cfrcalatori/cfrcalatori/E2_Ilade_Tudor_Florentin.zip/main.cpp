#include "main.h"
using namespace std;

int main() {
    MainManager app;
    app.start();
    return 0;
}
